$(document).ready(function () {

    $.ajax({
        url: "PlaceController",
        data: {op: "load"},
        type: 'POST',
        success: function (data, textStatus, jqXHR) {
            remplir(data);
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(textStatus);
        }
    });
    
    $("#add").click(function () {
      
        var numero = $("#Numero").val();
        var etat = $("#Etat").val();
        var type = $("#Type").val();
         var section = $("#Section").val();
    
         alert(numero + " " + etat +" "+ type +" "+section);
        
       $.ajax({
            url: "PlaceController",
            data: {numero: numero, etat: etat, type: type , section: section},
            type: 'POST',
            success: function (data, textStatus, jqXHR) {
                remplir(data);
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus);
            }
        });
    });


    $("#content").on("click", ".delete", function () {
       var id = $(this).closest("tr").find("td").eq(0).text();
       $.ajax({
        url: "PlaceController",
        data: {op: "delete", id:id},
        type: 'POST',
        success: function (data, textStatus, jqXHR) {
            remplir(data);
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(textStatus);
        }
    });
       
    });

    function remplir(data) {
        var ligne = "";
        data.forEach(function (e) {
            ligne += "<tr><td>" + e.id + "</td><td>" + e.numero + "</td><td>" + e.etat + "</td><td>" + e.type + " </td><td>" + e.section + "</td><td><button class='delete'>Supprimer</button></td><td>Modifier</td></tr>";
        });
        $("#content").html(ligne);
    }
});
