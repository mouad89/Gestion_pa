/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author MOUAD
 */
public class Section {
    private int id;
    private int code;

    public Section(int id, int code) {
        this.id = id;
        this.code = code;
    }

    public Section(int code) {
        this.code = code;
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    @Override
    public String toString() {
        return "Section{" + "id=" + id + ", code=" + code + '}';
    }
    
}
