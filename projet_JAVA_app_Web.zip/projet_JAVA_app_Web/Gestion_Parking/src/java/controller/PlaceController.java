/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import beans.Place;
import com.google.gson.Gson;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import service.PlaceService;
/**
 *
 * @author MOUAD
 */
@WebServlet(urlPatterns = {"/PlaceController"})
public class PlaceController  extends HttpServlet {

     private PlaceService ps = new PlaceService();
     
     protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (request.getParameter("op") != null) {
            if (request.getParameter("op").equals("load")) {
                response.setContentType("application/json");
                List<Place> Places = ps.findAll();
                Gson json = new Gson();
                response.getWriter().write(json.toJson(Places));

            } else if (request.getParameter("op").equals("delete")) {
                int id = Integer.parseInt(request.getParameter("id"));
                ps.delete(ps.findById(id));
                response.setContentType("application/json");
                List<Place> Places = ps.findAll();
                Gson json = new Gson();
                response.getWriter().write(json.toJson(Places));
            }

        } else {
            int numero = Integer.parseInt(request.getParameter("numero"));
            String etat = request.getParameter("etat");
            String type = request.getParameter("type");
            int section = Integer.parseInt(request.getParameter("section"));
          
            ps.create(new Place(numero, etat, type, section));
            response.setContentType("application/json");
            List<Place> Places = ps.findAll();
            Gson json = new Gson();

            response.getWriter().write(json.toJson(Places));
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
   
    
}
}
